import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import json
import sys

# Dataset
data = pd.read_csv('dataset.csv', delimiter='/')
data.columns = ['pregunta', 'respuesta']
data['pregunta'] = data['pregunta'].str.lower()

# Buscar en el dataset
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(data['pregunta'].values.astype('U'))

def obtener_respuesta(pregunta_usuario, data, tfidf_matrix, vectorizer):
    pregunta_usuario = pregunta_usuario.lower()
    tfidf_pregunta = vectorizer.transform([pregunta_usuario])
    similarities = cosine_similarity(tfidf_pregunta, tfidf_matrix)
    max_similarity_index = np.argmax(similarities)
    respuesta = data.iloc[max_similarity_index]['respuesta']
    return respuesta

# Usuario
while True:
    try:
        pregunta_usuario = input()
        
        if not pregunta_usuario:
            break

        respuesta = obtener_respuesta(pregunta_usuario, data, tfidf_matrix, vectorizer)
        respuestajson = json.dumps({"respuesta": respuesta.replace('\\n', '\n')})
        print(respuestajson)
        sys.stdout.flush() 
    except EOFError:
        break