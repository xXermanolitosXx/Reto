const express = require('express');
const cors = require('cors');
const { spawn } = require('child_process');

const app = express();
app.use(express.json());
app.use(cors());

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log("Server Listening on PORT:", PORT);
});

app.get("/status", (request, response) => {
    const status = {
        "Status": "Running"
    };
    response.send(status);
});

app.POST("/pregunta", (request, response) => {
    const pregunta_usuario = request.query.pregunta; // Utiliza request.query.pregunta para obtener la pregunta de la URL

    if (!pregunta_usuario) {
        return response.status(400).send("Debe proporcionar una pregunta en la URL");
    }

    const pythonProcess = spawn('python', ['ChatIA.py']);

    pythonProcess.stdin.write(pregunta_usuario + '\n');
    pythonProcess.stdin.end();

    let responseData = "";

    pythonProcess.stdout.on('data', (data) => {
        responseData += data.toString();
    });

    pythonProcess.stdout.on('end', () => {
        try {
            const jsonResponse = JSON.parse(responseData);
            response.send(jsonResponse);
        } catch (error) {
            console.error("Error parsing JSON:", error);
            response.status(500).send("Error en el servidor");
        }
    });

    pythonProcess.stderr.on('data', (data) => {
        console.error(`Error en el script de Python: ${data}`);
        response.status(500).send("Error en el servidor");
    });
});
